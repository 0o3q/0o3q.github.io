# Contract

## Installation
```
./build.sh
./run.sh
```

## Info

```
Network : http://localhost:12455

Player Account : 0x70997970C51812dc3A010C7d01b50e0d17dc79C8
Player Private Key : 0x59c6995e998f97a5a0044966f0945389dc9e86dae88c7a8412f4603b6b78690d

wETH deployed at: 0x5FbDB2315678afecb367f032d93F642f64180aa3
HTOToken deployed at: 0xe7f1725E7734CE288F8367e1Bb143E90bb3F0512
DepositNFT deployed at: 0x9fE46736679d2D9a65F0992F2272dE9f3c7fa6e0
VestingNFT deployed at: 0xCf7Ed3AccA5a467e9e704C703E8D87F634fB0Fc9
YieldVault deployed at: 0xDc64a140Aa3E981100a9becA4E685f962f0cF6C9
Swap deployed at: 0x8A791620dd6260079BF849Dc5567aDC3F2FdC318
```